import { useMemo, useState } from "react";
import { getSystemNowDate } from "@/lib/timeUtils";
import { Filter, Download, Loader2, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Transaction } from "@/lib/mock-data";
import type { ChargeRow } from "@/hooks/use-charges";
import {
  useMembers,
  useTransactions,
  useCompanySettings,
} from "@/hooks/use-firestore";
import { useCharges } from "@/hooks/use-charges";
import { formatNPR } from "@/lib/mock-data";
import { buildMemberLedger } from "@/lib/member-ledger";
import { exportTableToCSV } from "@/lib/print-utils";
import { toast } from "sonner";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

import { handlePrintReport } from "@/lib/print-utils";
import {
  underlineFirstChar,
  underlineSpecificChars,
} from "@/lib/string-case-change";

interface MemberLedgerRow {
  memberId: string;
  memberName: string;
  tier: string;
  services: string;
  totalBilled: number;
  totalPaid: number;
  netBalance: number;
  status: "Settled" | "Partial" | "Unpaid" | "Overpaid";
  memberStatus?: string;
}

export default function LedgerReport() {
  const { data: members = [], isLoading: mLoading } = useMembers();
  const { data: transactions = [], isLoading: txLoading } = useTransactions();
  const { data: charges = [] } = useCharges();
  const { data: settings = {} } = useCompanySettings();
  const isLoading = mLoading || txLoading;

  const [showFilters, setShowFilters] = useState(true);
  const [tierFilter, setTierFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState<
    "name-asc" | "name-desc" | "balance-desc" | "paid-desc"
  >("name-asc");
  const [searchQ, setSearchQ] = useState("");
  const [loaded, setLoaded] = useState(false);

  const propertyName = settings.companyName || ".............";

  const ledger: MemberLedgerRow[] = useMemo(() => {
    if (!loaded) return [];
    let list = members;
    if (tierFilter !== "all") list = list.filter((m) => m.tier === tierFilter);
    if (searchQ) {
      const q = searchQ.toLowerCase();
      list = list.filter(
        (m) =>
          m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q),
      );
    }

    const result = list.map<MemberLedgerRow>((m) => {
      const { summary } = buildMemberLedger(
        m.id,
        transactions,
        m.openingBalance || 0,
        charges,
      );
      const memberCharges = charges.filter((c) => c.member_id === m.id);
      const services =
        Array.from(
          new Set([
            ...memberCharges.map((c) => c.charge_head).filter(Boolean),
            ...transactions
              .filter((t) => t.memberId === m.id && t.chargeHead)
              .map((t) => t.chargeHead as string),
          ]),
        ).join(", ") ||
        (m.services || []).join(", ") ||
        "—";
      return {
        memberId: m.id,
        memberName: m.name,
        tier: m.tier,
        services,
        totalBilled: summary.totalCharged,
        totalPaid: summary.totalPaid + summary.advance + summary.discountTotal,
        netBalance: summary.netPayable,
        status: summary.status,
        memberStatus: m.status,
      };
    });

    const filtered =
      statusFilter === "all"
        ? result
        : result.filter((r) => r.status.toLowerCase() === statusFilter);

    switch (sortBy) {
      case "name-asc":
        filtered.sort((a, b) => a.memberName.localeCompare(b.memberName));
        break;
      case "name-desc":
        filtered.sort((a, b) => b.memberName.localeCompare(a.memberName));
        break;
      case "balance-desc":
        filtered.sort((a, b) => b.netBalance - a.netBalance);
        break;
      case "paid-desc":
        filtered.sort((a, b) => b.totalPaid - a.totalPaid);
        break;
    }
    return filtered;
  }, [
    members,
    transactions,
    charges,
    loaded,
    tierFilter,
    statusFilter,
    searchQ,
    sortBy,
  ]);

  const totalBilled = ledger.reduce((s, m) => s + m.totalBilled, 0);
  const totalPaid = ledger.reduce((s, m) => s + m.totalPaid, 0);
  const totalBalance = ledger.reduce((s, m) => s + m.netBalance, 0);

  const handleLoad = () => {
    setLoaded(true);
    setShowFilters(false);
    toast.success("Report loaded");
  };

  const headers = [
    "Member",
    "Services",
    "Total Billed (NPR)",
    "Total Paid (NPR)",
    "Net Balance (NPR)",
    "Status",
  ];
  const rows = ledger.map((m) => [
    m.memberName,
    m.services,
    String(m.totalBilled),
    String(m.totalPaid),
    String(m.netBalance),
    m.status,
    m.memberStatus || "—",
  ]);

  const handleExport = () => {
    exportTableToCSV(
      headers,
      rows,
      `member-ledger-${format(getSystemNowDate(), "yyyyMMdd")}.csv`,
      {
        propertyName,
        reportTitle: "Member Ledger Report",
        dateRange: format(getSystemNowDate(), "PPP"),
        filters: {
          Tier: tierFilter === "all" ? "All" : tierFilter,
          Status: statusFilter === "all" ? "All" : statusFilter,
          Search: searchQ || "—",
          "Total Members": String(ledger.length),
          "Total Billed (NPR)": String(totalBilled),
          "Total Paid (NPR)": String(totalPaid),
          "Total Balance (NPR)": String(totalBalance),
        },
      },
    );
    toast.success(`Exported ${ledger.length} member ledgers`);
  };

  const statusChip = (s: MemberLedgerRow["status"]) => {
    const cls =
      s === "Settled"
        ? "bg-success/20 text-success"
        : s === "Partial"
          ? "bg-amber-500/20 text-amber-500"
          : s === "Overpaid"
            ? "bg-blue-500/20 text-blue-500"
            : "bg-destructive/20 text-destructive";
    return <Badge className={cn("text-[10px] border-0", cls)}>{s}</Badge>;
  };

  return (
    <div className="rounded-xl overflow-hidden border border-border/60 bg-card">
      <div className="bg-gradient-to-r from-[hsl(220,70%,28%)] via-[hsl(220,70%,32%)] to-[hsl(220,70%,28%)] text-white px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h2 className="font-display font-bold text-lg leading-tight">
          Member Ledger Report
        </h2>

        <div className="flex gap-2">
          {!showFilters ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowFilters((p) => !p)}
              className="bg-white/10 hover:bg-white/20 text-white border-white/20"
            >
              <Filter className="h-4 w-4 mr-1.5" />
              {showFilters ? "Hide Filters" : "Show Filters"}
            </Button>
          ) : (
            <Button
              onClick={handleLoad}
              disabled={isLoading}
              variant="secondary"
              size="sm"
              accessKey="l"
              className="bg-white/10 hover:bg-white/20 text-white border-white/20"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : null}
              <Filter className="h-4 w-4 mr-1.5" />
              {underlineFirstChar("Load Report")}
            </Button>
          )}
          {/* // Handle Print Report of the members ledger if expanded, prints the sub details too */}
          <Button
            variant="secondary"
            size="sm"
            accessKey="p"
            onClick={() =>
              handlePrintReport(
                headers,
                rows,
                "Member Ledger Report",
                propertyName,
              )
            }
            disabled={rows.length === 0}
            className="bg-white/10 hover:bg-white/20 text-white border-white/20"
          >
            <Printer className="h-4 w-4 mr-1.5" />
            {underlineFirstChar("Print")}
          </Button>
          <Button
            size="sm"
            accessKey="x"
            onClick={handleExport}
            disabled={!loaded || ledger.length === 0}
            className="bg-success hover:bg-success/90 text-white"
          >
            <Download className="h-4 w-4 mr-1.5" />
            {underlineSpecificChars("Export CSV", [1])}
          </Button>
        </div>
      </div>

      {showFilters && (
        <div className="bg-[hsl(214,100%,97%)] dark:bg-muted/20 px-5 py-4 border-b border-border/50">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="space-y-1.5">
              <Input
                placeholder="Search name or email..."
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                className="bg-background"
              />
            </div>

            <div className="space-y-1.5">
              <Select value={tierFilter} onValueChange={setTierFilter}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tiers</SelectItem>
                  <SelectItem value="Basic">Basic</SelectItem>
                  <SelectItem value="Silver">Silver</SelectItem>
                  <SelectItem value="Gold">Gold</SelectItem>
                  <SelectItem value="Platinum">Platinum</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                  <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                  <SelectItem value="balance-desc">Highest Balance</SelectItem>
                  <SelectItem value="paid-desc">Highest Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )}
      {!loaded ? (
        <div className="p-8 text-center text-muted-foreground"></div>
      ) : isLoading ? (
        <div className="p-4 space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 rounded" />
          ))}
        </div>
      ) : ledger.length === 0 ? (
        <div className="p-12 text-center text-muted-foreground text-sm">
          No members match the current filters.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <div className="grid grid-cols-12 gap-2 bg-[hsl(220,70%,28%)] text-white text-xs font-semibold px-5 py-3">
            <div className="col-span-3">Member Name</div>
            <div className="col-span-3">Services</div>
            <div className="col-span-2 text-right">Total Billed (+)</div>
            <div className="col-span-2 text-right">Total Paid (−)</div>
            <div className="col-span-1 text-right">Net Balance</div>
            <div className="col-span-1 text-right">Status</div>
          </div>
          <Accordion type="multiple" className="w-full">
            {ledger.map((m) => (
              <AccordionItem
                key={m.memberId}
                value={m.memberId}
                className="border-b border-border/40 last:border-b-0"
              >
                <AccordionTrigger className="px-5 py-3 hover:no-underline hover:bg-muted/30 [&>svg]:ml-2">
                  <div className="grid grid-cols-12 gap-2 items-center text-sm w-full pr-2">
                    <div className="col-span-3 text-left">
                      <span className="font-semibold text-[hsl(220,70%,28%)] dark:text-primary">
                        {m.memberName}
                      </span>
                      <Badge variant="outline" className="text-[10px] ml-2">
                        {m.tier}
                      </Badge>
                    </div>
                    <div className="col-span-3 text-xs text-muted-foreground text-left truncate">
                      {m.services}
                    </div>
                    <div className="col-span-2 text-right font-medium">
                      {formatNPR(m.totalBilled)}
                    </div>
                    <div className="col-span-2 text-right font-medium text-success">
                      {formatNPR(m.totalPaid)}
                    </div>
                    <div
                      className={cn(
                        "col-span-1 text-right font-semibold",
                        m.netBalance > 0
                          ? "text-destructive"
                          : m.netBalance < 0
                            ? "text-blue-500"
                            : "text-success",
                      )}
                    >
                      {m.netBalance < 0
                        ? `(${formatNPR(Math.abs(m.netBalance))})`
                        : formatNPR(m.netBalance)}
                    </div>
                    <div className="col-span-1 text-right">
                      {statusChip(m.status)}
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="bg-muted/20 px-5 py-3">
                  <MemberBillsAccordion
                    memberId={m.memberId}
                    transactions={transactions}
                    charges={charges}
                    openingBalance={
                      (members.find((x) => x.id === m.memberId) as any)
                        ?.openingBalance || 0
                    }
                  />
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}
    </div>
  );
}

function SummaryCard({
  color,
  label,
  sub,
  value,
}: {
  color: string;
  label: string;
  sub: string;
  value: string;
}) {
  return (
    <div
      className="px-5 py-4 border-r border-border/40 last:border-r-0"
      style={{ background: `linear-gradient(180deg, ${color}10, transparent)` }}
    >
      <div className="font-bold text-lg" style={{ color }}>
        {value}
      </div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-[10px] text-muted-foreground/70">{sub}</div>
    </div>
  );
}

function MemberBillsAccordion({
  memberId,
  transactions,
  charges,
  openingBalance,
}: {
  memberId: string;
  transactions: Transaction[];
  charges: ChargeRow[];
  openingBalance: number;
}) {
  const { rows, summary } = buildMemberLedger(
    memberId,
    transactions,
    openingBalance,
    charges,
  );
  if (rows.length === 0) {
    return (
      <p className="text-xs text-muted-foreground py-2">
        No bills or receipts on file.
      </p>
    );
  }
  return (
    <div className="space-y-2">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[110px] text-xs">Date</TableHead>
            <TableHead className="text-xs">Description</TableHead>
            <TableHead className="text-right w-[110px] text-xs">
              Charge
            </TableHead>
            <TableHead className="text-right w-[110px] text-xs">Paid</TableHead>
            <TableHead className="text-right w-[120px] text-xs">
              Net Balance
            </TableHead>
            {/* <TableHead className="text-right w-[110px] text-xs"></TableHead> */}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r, i) => (
            <TableRow
              key={i}
              className={cn("text-xs", r.voided && "opacity-50 line-through")}
            >
              <TableCell>{r.date}</TableCell>
              <TableCell>
                {r.description}
                {r.receiptNo && (
                  <span className="block text-[10px] text-muted-foreground font-mono">
                    {r.receiptNo}
                  </span>
                )}
              </TableCell>
              <TableCell className="text-right">
                {r.debit ? formatNPR(r.debit) : "—"}
              </TableCell>
              <TableCell className="text-right text-success">
                {r.credit ? formatNPR(r.credit) : "—"}
              </TableCell>
              <TableCell className="text-right font-semibold">
                {formatNPR(r.balance)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className="flex justify-end gap-4 px-2 py-1 text-[11px] text-muted-foreground border-t border-border/40">
        <span>
          Billed: <strong>{formatNPR(summary.totalCharged)}</strong>
        </span>
        <span>
          Paid:{" "}
          <strong className="text-success">
            {formatNPR(summary.totalPaid)}
          </strong>
        </span>
        <span>
          {summary.netPayable < 0 ? "Refund Due" : "Balance"}:{" "}
          <strong
            className={
              summary.netPayable > 0
                ? "text-destructive"
                : summary.netPayable < 0
                  ? "text-blue-500"
                  : "text-success"
            }
          >
            {summary.netPayable < 0
              ? `(${formatNPR(Math.abs(summary.netPayable))})`
              : formatNPR(summary.netPayable)}
          </strong>
        </span>
      </div>
    </div>
  );
}
